'use strict';

module.exports = (sequelize, DataType) => {
  let Student = sequelize.define('Student', {
    // id missing because Sequelize adds it by default
    nome: DataType.STRING(30),
    marca: DataType.STRING(20),
    ram: DataType.INTEGER(3),
    memoria: DataType.INTEGER(4),
    risoluzFotocamera: DataType.INTEGER(3),
    dualSim: DataType.BOOLEAN(1),
    bluetooth: DataType.BOOLEAN(1),
    url: DataType.STRING(255)
    /*
    name:  DataType.STRING(100),
    phone: DataType.INTEGER(10),
    email: DataType.STRING(255)
    */
  }, {
    freezeTableName: true,
    timestamps: false,
    tableName: 'cellulare'
  });

  // Association to other models (foreign keys)
  Student.associate = function (models) {

  };

  return Student;
};
