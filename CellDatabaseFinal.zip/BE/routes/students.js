const express = require('express');
const router = express.Router();
const Student = require('../models/index').Student;

router.get('/', function (req, res, next) {
    Student.findAll({})
        .then(students => res.json(students))
        .catch(err => res.json(err))
    ;
});

router.get('/:id', function (req, res, next) {
    Student.findOne({
            where: {
                id: req.params.id
            }
        }
    )
        .then(student => res.json(student))
        .catch(err => res.json(err));
});

router.post('/', function (req, res, next) {
    const {nome, marca, ram, memoria, risoluzFotocamera, dualSim, bluetooth, url} = req.body;

    Student.create({
        nome: nome,
        marca: marca,
        ram: ram,
        memoria: memoria,
        risoluzFotocamera: risoluzFotocamera,
        dualSim: dualSim,
        bluetooth: bluetooth,
        url: url
    })
        .then(student => res.status(201).json({
            student
        }))
        .catch(error => res.status(500).json({
            error
        }));
});

router.put('/:id', function (req, res, next) {
    const st_id = req.params.id;
    const {nome, marca, ram, memoria, risoluzFotocamera, dualSim, bluetooth, url} = req.body;

    console.log(req.body);

    Student.update({
        nome: nome,
        marca: marca,
        ram: ram,
        memoria: memoria,
        risoluzFotocamera: risoluzFotocamera,
        dualSim: dualSim,
        bluetooth: bluetooth,
        url: url
    }, {
        where: {
            id: st_id
        }
    })
        .then(student => res.status(201).json({
            student
        }))
        .catch(error => res.status(500).json({
            error
        }));
});

router.delete('/:id', function (req, res, next) {
    const st_id = req.params.id;

    Student.destroy({
        where: {
            id: st_id
        }
    })
        .then(status => res.status(201).json({
            error: false
        }))
        .catch(err => res.status(500).json({
            error: err
        }));
});

module.exports = router;