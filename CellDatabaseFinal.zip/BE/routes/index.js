const express = require('express');
const router = express.Router();

/* GET home page */
router.get('/', function (req, res) {
    return res.status(200).send({
      isConnected: true,
      message: 'Hello world!'
    })
});


module.exports = router;
