import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CellulareEditComponent } from './cellulare-edit.component';

describe('CellulareEditComponent', () => {
  let component: CellulareEditComponent;
  let fixture: ComponentFixture<CellulareEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CellulareEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CellulareEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
