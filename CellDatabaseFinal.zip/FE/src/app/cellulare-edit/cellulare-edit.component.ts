import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CellulareService } from '../shared/services/cellulare.service';
import { Cellulare } from '../shared/models/Cellulare';

@Component({
  selector: 'app-cellulare-edit',
  templateUrl: './cellulare-edit.component.html',
  styleUrls: ['./cellulare-edit.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CellulareEditComponent implements OnInit {

  cellulare: Cellulare;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private cellulareService: CellulareService
  ) { }

  ngOnInit() {
    this.getCellulare(this.route.snapshot.params['id']);
  }
  
  getCellulare(id) {
    this.cellulareService.getCellulareById(id)
      .subscribe(data => {
        this.cellulare = data;
      });
  }

  updateCellulare(id) {
    this.cellulareService.editCellulare(this.cellulare)
      .subscribe(res => {
        this.router.navigate(['/cellulare-details', id]);
      }, (err) => {
        console.log(err);
      });
  }

}
