import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {RouterModule, Routes} from '@angular/router';

// ogni component deve essere importato qui dentro

import {AppComponent} from './app.component';
import {CellulareComponent} from './cellulare/cellulare.component';
import {CellulareDetailComponent} from './cellulare-detail/cellulare-detail.component';
import {CellulareCreateComponent} from './cellulare-create/cellulare-create.component';
import {CellulareEditComponent} from './cellulare-edit/cellulare-edit.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import {CellulareService} from './shared/services/cellulare.service';

const appRoutes: Routes = [
    {
        path: 'cellulari',
        component: CellulareComponent,
        data: {title: 'Cellulari Lista'}
    },
    {
        path: 'cellulare-details/:id',
        component: CellulareDetailComponent,
        data: {title: 'Cellulare Details'}
    },
    {
        path: 'cellulare-create',
        component: CellulareCreateComponent,
        data: {title: 'Create a new Cellulare'}
    },
    {
        path: 'cellulare-edit/:id',
        component: CellulareEditComponent,
        data: {title: 'Edit Cellulare'}
    },
    {
        path: '',
        redirectTo: '/cellulari',
        pathMatch: 'full'
    },
    {
        path: '**',
        component: PageNotFoundComponent,
        data: {title: 'Page Not Found'}
    }
];

// ogni component deve essere dichiarato qui dentro
@NgModule({
    declarations: [
        AppComponent,
        CellulareComponent,
        CellulareDetailComponent,
        CellulareCreateComponent,
        CellulareEditComponent,
        PageNotFoundComponent
    ],
    imports: [
        BrowserModule,
        FormsModule,
        HttpClientModule,
        RouterModule.forRoot(
            appRoutes,
        )
    ],
    providers: [CellulareService],
    bootstrap: [AppComponent] // All'avvio faccio partire AppComponent
})
export class AppModule {
}
