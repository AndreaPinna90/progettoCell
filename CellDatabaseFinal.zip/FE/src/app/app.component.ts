import { Component } from '@angular/core'; // importo il componente di angular

@Component({
  selector: 'app-root', // è lo stesso che troviamo dentro il body
  templateUrl: './app.component.html', // qui troviamo il template html
  styleUrls: ['./app.component.css'] // qui invece i fogli di stile
})
export class AppComponent { // deve essere visto all'esterno
  title = 'app';
}
