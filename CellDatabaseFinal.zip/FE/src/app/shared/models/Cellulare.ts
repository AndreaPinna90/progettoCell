import { Url } from 'url';

export class Cellulare {
  id?: number;
  nome?: string;
  marca?: string;
  ram?: number;
  memoria?: number;
  risoluzFotocamera?: number;
  dualSim?: boolean;
  bluetooth?: boolean;
  url?: string;
}