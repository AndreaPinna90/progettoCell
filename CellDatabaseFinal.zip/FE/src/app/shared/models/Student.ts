export interface Student {
  id?: number;
  name?: string;
  phone?: number;
  email?: string;
}
