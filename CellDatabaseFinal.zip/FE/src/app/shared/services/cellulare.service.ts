import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Cellulare} from '../models/Cellulare';
import {environment} from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CellulareService {

  private baseUrl = `${environment.apiUrl}/students`;

  constructor(private http: HttpClient) {
  }

  getCellulari = () => {
    return this.http.get<Array<Cellulare>>(this.baseUrl);
  };

  getCellulareById = (id) => {
    return this.http.get<Cellulare>(`${this.baseUrl}/${id}`);
  };

  insertCellulare = (cellulare: Cellulare) => {
    return this.http.post<Cellulare>(this.baseUrl, {nome: cellulare.nome, marca: cellulare.marca, ram: cellulare.ram, memoria: cellulare.memoria, risoluzFotocamera: cellulare.risoluzFotocamera, dualSim: cellulare.dualSim, bluetooth: cellulare.bluetooth, url: cellulare.url}); // {...cellulare}
  };

  editCellulare = (cellulare: Cellulare) => {
    return this.http.put(`${this.baseUrl}/${cellulare.id}`, {...cellulare});
  };

  deleteCellulare = (id) => {
    return this.http.delete(`${this.baseUrl}/${id}`);
  };
}
