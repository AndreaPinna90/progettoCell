import { TestBed } from '@angular/core/testing';

import { CellulareService } from './cellulare.service';

describe('CellulareService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CellulareService = TestBed.get(CellulareService);
    expect(service).toBeTruthy();
  });
});
