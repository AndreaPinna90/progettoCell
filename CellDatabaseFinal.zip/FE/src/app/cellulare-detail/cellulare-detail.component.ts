import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CellulareService } from '../shared/services/cellulare.service';
import { Cellulare } from '../shared/models/Cellulare';

@Component({
  selector: 'app-cellulare-detail',
  templateUrl: './cellulare-detail.component.html',
  styleUrls: ['./cellulare-detail.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CellulareDetailComponent implements OnInit {

  cellulare: Cellulare;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private cellulareService: CellulareService
  ) { }

  ngOnInit() {
    this.getCellulareDetail(this.route.snapshot.params.id);
  }

  getCellulareDetail(id) {
    this.cellulareService.getCellulareById(id)
      .subscribe(data => {
        this.cellulare = data;
      });
  }

  deleteCellulare(id) {
    this.cellulareService.deleteCellulare(id)
      .subscribe(data => {
        this.router.navigate(['/cellulari']);
      }, (err) => {
        console.log(err);
      });
  }

}
