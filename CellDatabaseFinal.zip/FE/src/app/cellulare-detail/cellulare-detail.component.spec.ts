import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CellulareDetailComponent } from './cellulare-detail.component';

describe('CellulareDetailComponent', () => {
  let component: CellulareDetailComponent;
  let fixture: ComponentFixture<CellulareDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CellulareDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CellulareDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
