import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { CellulareService } from '../shared/services/cellulare.service';
import { Cellulare } from '../shared/models/Cellulare';

@Component({
  selector: 'app-cellulare-create',
  templateUrl: './cellulare-create.component.html',
  styleUrls: ['./cellulare-create.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CellulareCreateComponent implements OnInit {

  cellulare: Cellulare = {
    nome: '',
    marca: '',
    ram: 0,
    memoria: 0,
    risoluzFotocamera: 0,
    dualSim: false,
    bluetooth: false,
    url: ''
  };

  constructor(
    private cellulareService: CellulareService,
    private router: Router
  ) { }

  ngOnInit() {
  }

  saveCellulare() {
    this.cellulareService.insertCellulare(this.cellulare)
      .subscribe(res => {
          this.router.navigate(['/cellulari']);
        }, (err) => {
          console.log(err);
        }
      );
  }

}
