import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CellulareCreateComponent } from './cellulare-create.component';

describe('CellulareCreateComponent', () => {
  let component: CellulareCreateComponent;
  let fixture: ComponentFixture<CellulareCreateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CellulareCreateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CellulareCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
