import { Component, OnInit } from '@angular/core';
import {CellulareService} from '../shared/services/cellulare.service';
import {Cellulare} from '../shared/models/Cellulare';

@Component({
  selector: 'app-cellulare',
  templateUrl: './cellulare.component.html',
  styleUrls: ['./cellulare.component.css']
})
// quando creo un nuovo componente devo mettere queste cose, selector avrà app-nome comp
// quello che utilizziamo per richiamare il comp denrto html
// templateUrl: il path del template html, colendo posso mettere l'html qui dentro, ma secondo me è brutto
// styleUrls il path per il foglio di stile
export class CellulareComponent implements OnInit {
  cellulari: Array<Cellulare>;

  constructor(
    private cellulareService: CellulareService
  ) { }

  ngOnInit() {
    this.cellulareService.getCellulari()
      .subscribe((data: Array<Cellulare>) => {
        this.cellulari = data;
      });
  }
  

}
