import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CellulareComponent } from './cellulare.component';

describe('CellulareComponent', () => {
  let component: CellulareComponent;
  let fixture: ComponentFixture<CellulareComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CellulareComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CellulareComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
