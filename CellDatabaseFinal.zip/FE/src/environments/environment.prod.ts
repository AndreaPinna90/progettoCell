export const environment = {
  production: true,
  apiUrl: 'https://students-be.herokuapp.com'
};
